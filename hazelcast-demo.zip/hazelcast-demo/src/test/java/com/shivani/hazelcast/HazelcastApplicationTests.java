package com.shivani.hazelcast;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HazelcastApplicationTests {

	@Test
	void contextLoads() {
	}

}
