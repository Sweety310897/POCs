package com.shivani.hazelcast;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hazelcast.core.IMap;

@RestController
public class Controller {

	
	@Autowired
	IMap<String, String> usersMap;
	@RequestMapping(path="/putValue")
	public String putValue(@RequestParam(name="key") String key, @RequestParam(name="value") String value ) {
		usersMap.put(key, value);
		return "data is stored";
	}
	
	
	
	@RequestMapping(path="/gettValue")
	public String getValue(@RequestParam(name="key") String key) {
		return usersMap.get(key);
	}
	
	
	
}
